create view activeproducts as
select `computerstore`.`products`.`ID`               AS `ID`,
       `computerstore`.`products`.`Name`             AS `Name`,
       `computerstore`.`products`.`SupplerCompany`   AS `SupplerCompany`,
       `computerstore`.`products`.`Category`         AS `Category`,
       `computerstore`.`products`.`Price`            AS `Price`,
       `computerstore`.`products`.`CountAll`         AS `CountAll`,
       `computerstore`.`products`.`AmmountsProducts` AS `AmmountsProducts`,
       `computerstore`.`products`.`Rating`           AS `Rating`,
       `computerstore`.`products`.`Descriprion`      AS `Descriprion`,
       `computerstore`.`products`.`Status`           AS `Status`
from `computerstore`.`products`
where (`computerstore`.`products`.`Status` = true);

