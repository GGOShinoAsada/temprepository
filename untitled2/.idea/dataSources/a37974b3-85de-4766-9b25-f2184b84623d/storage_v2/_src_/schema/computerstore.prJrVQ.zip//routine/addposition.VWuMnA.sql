create
    definer = root@localhost procedure addposition(IN posname varchar(50), IN descr varchar(100))
BEGIN
if (posname<>"" or descr<>"") then 
insert into positions (positionname, description) values (posname, descr);
end if;
END;

